

<?php $__env->startSection('tittle','Catagories'); ?>

<?php $__env->startSection('content'); ?>
<div class="row clearfix mb-4">
	<div class="col-md-6">
	<h3>Category List</h3>	
	</div>
	<div class="col-md-6 text-right">
    <div>
        
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><b>+</b> Add Categories</a>
    </div>
	</div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
    	<h6 class="m-0 font-weight-bold text-primary">Users</h6>
    </div>
    <div class="card-body">
         <?php if(session('message')): ?>
            <div class="alert alert-success" role="alert">
                <h5><?php echo e(session('message')); ?></h5>
            </div>
         <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Category tittle</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Category tittle</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </tfoot>
                <tbody>
                 	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td class="text-right">
                        <?php echo Form::open(['url' => 'categories/'.$category->id,'method'=>'delete']); ?>

                           <a href="<?php echo e(route('category.edit',['id'=>$category->id])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                        	<button onclick="return confirm('Are you sure')" class="btn btn-danger mb-1 btn-sm"> <i class="fa fa-trash"></i> </button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\AmarDokan-server\resources\views/Home/Product/category.blade.php ENDPATH**/ ?>