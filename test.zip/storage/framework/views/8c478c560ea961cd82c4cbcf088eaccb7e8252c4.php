

<?php $__env->startSection('tittle','Create Categories'); ?>

<?php $__env->startSection('content'); ?>

<h3><?php echo e($headline); ?></h3>
  <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Categories</h6>
    </div>
    <div class="card-body">
      <div class="row justify-content-md-center">
	       <div class="col-md-6"> 
		    	<?php if($errors->any()): ?>
		    		<div class="alert alert-danger">
		    			<ul>
		    				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    					<li><?php echo e($error); ?></li>
		    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    			</ul>
		    		</div>
		    	<?php endif; ?>
		   			<?php if(isset($category)): ?>
		   				<?php echo Form::model($category, [ 'route' => ['category.update', $category->id], 'method' => 'put' ]); ?>

		   			<?php else: ?>
		   				<?php echo Form::open(['route' => 'category.store','method'=>'post']); ?>

		   			<?php endif; ?>
					   <div class="form-group">
					    <label for="title">Category<i class="text-danger">*</i></label>
					    <?php echo e(Form::text('name',NULL,['class' => 'form-control','id'=> 'title', 'placeholder'=> 'Enter categories name'])); ?>

					  </div>
					  
					  <div class="text-right">
					  	<button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
					  </div>
				<?php echo Form::close(); ?>

			  </div>
		 </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\AmarDokan-server\resources\views/Home/Product/category_form.blade.php ENDPATH**/ ?>