

<?php $__env->startSection('tittle','AmarDokan-Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h2>Hello</h2>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\AmarDokan-server\resources\views/Home/index.blade.php ENDPATH**/ ?>