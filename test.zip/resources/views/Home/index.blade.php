@extends('layout.app')

@section('tittle','AmarDokan-Admin')

@section('content')
    <div>
        <h2>Hello</h2>
</div>

@stop